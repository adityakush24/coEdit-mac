function onBoardInit() {

  electronAPI.setFullScreen();
  electronAPI.setAlwaysOnTop(true);

  // Initialize Firebase.
  const firebaseConfig = {
    apiKey: "AIzaSyCtY5kmSK7BfM5MSe_Tlj65YnTjI8PfFiQ",
    authDomain: "coedit-d3578.firebaseapp.com",
    databaseURL: "https://coedit-d3578-default-rtdb.firebaseio.com",
    projectId: "coedit-d3578",
    storageBucket: "coedit-d3578.appspot.com",
    messagingSenderId: "766722701197",
    appId: "1:766722701197:web:27a390e8e34f9d981f6fc4"
  };
  firebase.initializeApp(firebaseConfig);

  // Get Firebase Database reference.
  var roomName = sessionStorage.getItem('roomName');
  var firepadContainer = document.getElementById('firepad-container');
  var firepadRef = firebase.database().ref().child(roomName);
  var browserControlsDbRef = firepadRef.child('browserControls');

  // Create CodeMirror (with lineWrapping on).
  var codeMirror = CodeMirror(firepadContainer, { lineWrapping: true });

  // Create Firepad
  var firepad = Firepad.fromCodeMirror(firepadRef, codeMirror,
    { richTextToolbar: false, richTextShortcuts: true });

  // Initialize contents.
  firepad.on('ready', function () {
    if (firepad.isHistoryEmpty()) {
      firepad.setHtml('Type here...');
    }
  });

  var isBrowserHidden = true;
  var isClickDisabled = false;
  var isMenuVisible = false;
  let menuBtn = document.getElementById('menuBtn');
  var browserView = document.getElementById('browserView');
  cursorToggle.addEventListener('mouseenter', () => {
    if (isClickDisabled) {
      cursorToggle.style.backgroundImage = "url(../assets/cursor.png)";
      electronAPI.setIgnoreMouseEvents(false);
      isClickDisabled = false;
    } else {
      electronAPI.setIgnoreMouseEvents(true)
      cursorToggle.style.backgroundImage = "url(../assets/cursorCross.png)";
      isClickDisabled = true;
    }
  })

  document.addEventListener('paste', function (clipboardEvent) {
    var clipboardItemType = clipboardEvent.clipboardData.types[0];
    if (clipboardItemType != "Files") {
      return;
    } else {
      var clipboardImageObjectUrl = URL.createObjectURL(clipboardEvent.clipboardData.files[0]);
      firepad.insertEntity('img', { src: clipboardImageObjectUrl });
    }
  });

  menuBtn.addEventListener('mouseenter', () => {
    if (isMenuVisible) {
      options.style.display = "none";
      menuBtn.style.backgroundImage = "url(../assets/menuCross.png)";
      isMenuVisible = false;
    } else {
      options.style.display = "block";
      menuBtn.style.backgroundImage = "url(../assets/menu.png)";
      isMenuVisible = true;
    }
  })


  var sliderOpacity = document.getElementById("OpacityValue");
  var sliderFont = document.getElementById("fontSize");
  var sliderColor = document.getElementById("colorPicker");
  var sliderColorFont = document.getElementById("colorPickerFont");
  var outputOpacity = document.getElementById("OpacityValueShow");
  var outputFont = document.getElementById("FontValueShow");

  outputOpacity.innerHTML = sliderOpacity.value;
  outputFont.innerHTML = sliderFont.value;

  sliderOpacity.oninput = function () {

    var op = this.value / 100;
    outputOpacity.innerHTML = this.value;
    var color = hexToRgb(sliderColor.value);

    document.getElementById("thisBody").style.background = `rgba${color},${op})`
  }
  sliderFont.oninput = function () {

    var size = this.value;
    outputFont.innerHTML = this.value;
    document.getElementById("thisBody").style.fontSize = `${size}px`
  }
  sliderColor.oninput = function () {
    var color = hexToRgb(sliderColor.value);
    document.getElementById("thisBody").style.background = `rgba${color},${sliderOpacity.value / 100})`
  }
  sliderColorFont.oninput = function () {
    document.getElementById("thisBody").style.color = sliderColorFont.value
  }
  function hexToRgb(h) {
    let r = 0, g = 0, b = 0;

    // 3 digits
    if (h.length == 4) {
      r = "0x" + h[1] + h[1];
      g = "0x" + h[2] + h[2];
      b = "0x" + h[3] + h[3];

      // 6 digits
    } else if (h.length == 7) {
      r = "0x" + h[1] + h[2];
      g = "0x" + h[3] + h[4];
      b = "0x" + h[5] + h[6];
    }

    return "(" + +r + "," + +g + "," + +b;
  }

  browserTransparencyRange.addEventListener('change', function (event) {
    var opacityValue = event.target.value;
    changeBrowserOpacity(opacityValue);
  });

  function changeBrowserOpacity(opacityValue) {
    document.getElementById("thisBody").style.opacity = opacityValue;
  }

  showBrowser.addEventListener("mouseenter", function () {
    if (isBrowserHidden) {
      browserView.style.display = "inline-flex";
      browserView.style.height = "100%";
      browserView.style.width = "42rem";
      showBrowser.style.backgroundImage = "url(../assets/browser.png)";
      browserControls.style.display = "inline";
      firepadContainer.style.position = "absolute";
      firepadContainer.style.top = "4%";
      firepadContainer.style.left = "70%";
      firepadContainer.style.width = "20rem";
      isBrowserHidden = false;
    } else {
      isBrowserHidden = true;
      browserView.style.height = "0%";
      browserView.style.width = "0%";
      browserControls.style.display = "none";
      showBrowser.style.backgroundImage = "url(../assets/browserCross.png)";
      firepadContainer.style.position = "relative";
      firepadContainer.style.top = "";
      firepadContainer.style.left = "";
      firepadContainer.style.width = "";
    }
  });

  browserBack.addEventListener("click", function () {
    browserView.goBack();
  });

  urlField.addEventListener("click", function () {
    urlField.select();
  });

  function validURL(str) {
    var pattern = new RegExp('^(https?:\\/\\/)?' + // protocol
      '((([a-z\\d]([a-z\\d-]*[a-z\\d])*)\\.)+[a-z]{2,}|' + // domain name
      '((\\d{1,3}\\.){3}\\d{1,3}))' + // OR ip (v4) address
      '(\\:\\d+)?(\\/[-a-z\\d%_.~+]*)*' + // port and path
      '(\\?[;&a-z\\d%_.~+=-]*)?' + // query string
      '(\\#[-a-z\\d_]*)?$', 'i'); // fragment locator
    return !!pattern.test(str);
  }

  function loadURL() {
    browserControlsDbRef.child('url').once("value", function (snapshot) {
      var url = snapshot.val() || urlField.value;
      var isValidUrl = validURL(url);
      if (isValidUrl) {
        if (url.indexOf("http") >= 0) {
          loadPage(url);
        } else {
          url = "http://" + url;
          loadPage(url);
        }
      } else {
        url = "https://www.google.com/search?q=" + url;
        loadPage(url);
      }
    });
  }

  function loadPage(url) {
    if (url.toLowerCase().indexOf("youtube.com/watch") >= 0) {
      var youtubeID = url.substring(url.indexOf("v=") + 2);
      youtubeID = youtubeID.split('&')[0];
      var youtubeURL = "https://www.youtube.com/embed/" + youtubeID;
      urlField.val(youtubeURL);
      browserView.loadURL(youtubeURL);
    } else {
      browserView.loadURL(url);
    }
  }


  urlField.addEventListener("keyup", (event) => {
    if (event.key === "Enter") {
      event.preventDefault();
      browserControlsDbRef.child('url').set(urlField.value);
      browserControlsDbRef.child('url').on('value', loadURL);
    }
  });


  browserHome.addEventListener("click", function () {
    loadPage("https://www.google.com");
  });
}