// All of the Node.js APIs are available in the preload process.
// It has the same sandbox as a Chrome extension.

const { contextBridge, ipcRenderer } = require('electron')

window.addEventListener('DOMContentLoaded', () => {
  const replaceText = (selector, text) => {
    const element = document.getElementById(selector)
    if (element) element.innerText = text
  }

  for (const type of ['chrome', 'node', 'electron']) {
    replaceText(`${type}-version`, process.versions[type])
  }

})

contextBridge.exposeInMainWorld('electronAPI', {
  setAlwaysOnTop: (isAlwaysOnTopEnabled) => ipcRenderer.send('set-always-on-top', isAlwaysOnTopEnabled),
  setIgnoreMouseEvents: (areMouseEventsEnabled) => ipcRenderer.send('set-ignore-mouse-events', areMouseEventsEnabled),
  setFullScreen: () => ipcRenderer.send('set-fullscreen'),
  closeApp: () => ipcRenderer.send('close-app')
})