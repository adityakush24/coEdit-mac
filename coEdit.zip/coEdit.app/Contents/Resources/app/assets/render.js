const electron = require('electron');
const path = require('path');
const remote = electron.remote;

document.querySelector('#closeBtn').addEventListener('click', () => {

  var window = remote.getCurrentWindow();
  window.close();
});

document.querySelector('#roomConnectBtn').addEventListener('click', () => {
  var roomName = document.querySelector('#roomName').value;
  sessionStorage.setItem('roomName', roomName);
});
